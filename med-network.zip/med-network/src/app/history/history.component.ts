import { Component, OnInit } from '@angular/core';
import { HistoryService } from './history.service';
import { FormGroup, FormControl, Validators, FormBuilder } from '@angular/forms';

@Component({
  selector: 'app-history',
  templateUrl: './history.component.html',
  styleUrls: ['./history.component.css'],
  providers: [HistoryService]
})
export class HistoryComponent implements OnInit {


  private allAssets;
  private asset;
  private errorMessage;
  private patientId;

  constructor(public serviceHistory: HistoryService) { 
    
  }

  ngOnInit() {
  }
  
  getForm(id: any): Promise<any> {
    const tempList = [];
    const modifiedId = 'org.example.basic.Patient%23' + id;
    console.log(modifiedId);

    return this.serviceHistory.queryAsset(modifiedId)
    .toPromise()
    .then((result) => {
      this.errorMessage = null;
      result.forEach(asset => {
        tempList.push(asset);
      });
      this.allAssets = tempList;
      console.log(this.allAssets);

    })
    .catch((error) => {
      if (error === 'Server error') {
        this.errorMessage = 'Could not connect to REST server. Please check your configuration details';
      } else if (error === '404 - Not Found') {
        this.errorMessage = '404 - Could not find API route. Please check your available APIs.';
      } else {
        this.errorMessage = error;
      }
    });
  }
}
